
public class Main {
    public static void main(String[] args) {

        //ingreso y muestra de datos del la clase Cliente
        Cliente cliente = new Cliente();
        cliente.setEdad(54);
        cliente.setNombre("Abel");
        cliente.setTelefono(12344321);
        cliente.setCredito(4500.60);

        System.out.println(
                "Datos del cliente:" + "\n" +
                "Edad: " + cliente.getEdad() + "\n" +
                "Nombre: " + cliente.getNombre() + "\n" +
                "Teléfono: " + cliente.getTelefono() + "\n" +
                "Crédito: " + cliente.getCredito()
        );
        System.out.println("----------------------");
        //ingreso y muestra de datos del la clase Trabajador
        Trabajador trabajador = new Trabajador();
        trabajador.setEdad(43);
        trabajador.setNombre("Ramiro");
        trabajador.setTelefono(12341234);
        trabajador.setSalario(1600);

        System.out.println(
                "Datos del trabajador:" + "\n" +
                        "Edad: " + trabajador.getEdad() + "\n" +
                        "Nombre: " + trabajador.getNombre() + "\n" +
                        "Teléfono: " + trabajador.getTelefono() + "\n" +
                        "Salario: " + trabajador.getSalario()
        );
    }
}

class Persona {
    int edad;
    String nombre;
    int telefono;

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getEdad() {
        return edad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public int getTelefono() {
        return telefono;
    }
}

class Cliente extends Persona {
    double credito;

    public void setCredito(double credito) {
        this.credito = credito;
    }

    public double getCredito() {
        return credito;
    }
}

class Trabajador extends Persona {
    double salario;

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }
}