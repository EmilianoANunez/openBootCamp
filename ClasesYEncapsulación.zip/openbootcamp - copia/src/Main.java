public class Main {
    public static void main(String[] args) {
        //Le doy valores a las clases privadas por medio de setters
        Persona persona = new Persona();
        persona.setEdad(34);
        persona.setNombre("María");
        persona.setTelefono(6666666);

        //Muestro las clases privadas de la clase persona por medio de getters
        System.out.println(
                "edad: " + persona.getEdad() + "\n" +
                "Nombre: " + persona.getNombre() + "\n" +
                "Teléfono: " + persona.getTelefono()
        );
    }
}
class Persona {
    // Variables privadas
    private int edad;
    private String nombre;
    private int telefono;

    //Set y Get de cada una
    public void setEdad (int edad) {
        this.edad = edad;
    }
    public int getEdad () {
        return this.edad;
    }
    public void setNombre (String nombre) {
        this.nombre = nombre;
    }
    public String getNombre () {
        return this.nombre;
    }
    public void setTelefono (int telefono) {
        this.telefono = telefono;
    }
    public int getTelefono () {
        return this.telefono;
    }
}
