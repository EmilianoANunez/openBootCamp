package com.ejercicio;

public class Main {
    public static void main(String[] args) {

        // cear SmartPhone
        SmartDevice movil = new SmartPhone(
                "Samsung",
                "A51",
                "7 Pulgadas",
                "1 TB",
                8,
                3,
                true
        );

        // crear SmartWatch
        SmartDevice reloj = new SmartWatch("Huawei",
                "m5",
                "2 Pulgadas",
                "16 Gb",
                2,
                "Tela",
                "Moderno"
        );

        // mostrar los atributos de cada uno

        System.out.println(movil + "\n" + reloj);

    }

    public static class SmartPhone extends SmartDevice {

        // 1. atributos

        int camarasTraseras;
        boolean camaraDelantera;

        // 2. constructores

        public SmartPhone() {

        }
        public SmartPhone(String marca, String modelo, String pantallaPulgadas, String almacenamiento, int ram, int camarasTraseras, boolean camaraDelantera) {
            super(marca, modelo, pantallaPulgadas, almacenamiento, ram);
            this.camarasTraseras = camarasTraseras;
            this.camaraDelantera = camaraDelantera;
        }

        // 3. metodo

        @Override
        public String toString() {
            return "SmartPhone{" +
                    "camarasTraseras=" + camarasTraseras +
                    ", camaraDelantera=" + camaraDelantera +
                    ", marca='" + marca + '\'' +
                    ", modelo='" + modelo + '\'' +
                    ", pantallaPulgadas='" + pantallaPulgadas + '\'' +
                    ", almacenamiento='" + almacenamiento + '\'' +
                    ", ram=" + ram +
                    '}';
        }
    }
    public static class SmartWatch extends SmartDevice {

        // 1. atributos

        String correa;
        String estilo;

        // 2. constructores

        public SmartWatch(){

        }
        public SmartWatch(String marca, String modelo, String pantallaPulgadas, String almacenamiento, int ram, String correa, String estilo) {
            super(marca, modelo, pantallaPulgadas, almacenamiento, ram);
            this.correa = correa;
            this.estilo = estilo;
        }

        // 3. metodo

        @Override
        public String toString() {
            return "SmartWatch{" +
                    "correa='" + correa + '\'' +
                    ", estilo='" + estilo + '\'' +
                    ", marca='" + marca + '\'' +
                    ", modelo='" + modelo + '\'' +
                    ", pantallaPulgadas='" + pantallaPulgadas + '\'' +
                    ", almacenamiento='" + almacenamiento + '\'' +
                    ", ram=" + ram +
                    '}';
        }
    }
}
