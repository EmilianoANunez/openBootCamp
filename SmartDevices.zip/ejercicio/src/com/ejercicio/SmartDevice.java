package com.ejercicio;

public class SmartDevice {
    // 1. atributos
    String marca;
    String modelo;
    String pantallaPulgadas;
    String almacenamiento;
    int ram;


    // 2. constructores

    public SmartDevice() {

    }

    public SmartDevice(String marca, String modelo, String pantallaPulgadas, String almacenamiento, int ram) {
        this.marca = marca;
        this.modelo = modelo;
        this.pantallaPulgadas = pantallaPulgadas;
        this.almacenamiento = almacenamiento;
        this.ram = ram;
    }


}
