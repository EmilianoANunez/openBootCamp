public class ArrayBidimensional {
    /*
     * Problema:
     * 2. Crea un array bidimensional de enteros y recórrelo,
     * mostrando la posición y el valor de cada elemento en ambas
     * dimensiones.
     */

    public static void main(String[] args) {
        /*
         * se crea un array bidimensional
         * y luego se lo recorre por su eje X y Z con un for
         */

        int[][] array2D = {
                {1, 2, 3},
                {4, 5, 6}
        };

        // muestra
        for (int x = 0; x < array2D.length; x++) {
            System.out.println("Dentro del eje X n°: " + x);
            for (int y = 0; y < array2D[x].length; y++) {
                System.out.print(
                        "En el eje Y n°: " + y +
                        " Se encuentra el número: " + array2D[x][y]
                        + "\n"
                );
            }
        }
    }
}
