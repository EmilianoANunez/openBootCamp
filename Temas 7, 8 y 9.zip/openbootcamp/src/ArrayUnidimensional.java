public class ArrayUnidimensional {
    /*
     * Problema:
     * 1. Crea un array unidimensional de Strings
     * y recórrelo, mostrando únicamente sus valores.
     */

    public static void main(String[] args) {
        /*
         * se recorre el array para mostrar por pantalla
         * cada uno de sus valores
         */

        String[] array = new String[]{
                "s", "o", "y", " ",
                "u", "n", " ",
                "a", "r", "r", "a", "y"
        };

        for (String cadena : array) {
            System.out.println(cadena);
        }
    }
}
