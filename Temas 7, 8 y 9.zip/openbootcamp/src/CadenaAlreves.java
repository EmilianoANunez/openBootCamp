public class CadenaAlreves {
    /*
     * Problema:
     * Dada la función:
     * public static String reverse(String texto) { }
     * Escribe el código que devuelva una cadena al revés.
     * Por ejemplo, la cadena "hola mundo", debe retornar "odnum aloh".
     */

    public static void main(String[] args) {
        /*
         se crean dos strings, uno el principal "texto" y
         el secundario "textoModificado" que se le va a asignar
         la salida de la función reverse
         */
        String texto = "hola mundo";
        String textoModificado = reverse(texto);
        System.out.println(textoModificado);

    }
    public static String reverse(String texto) {
        /*
         para sacar los valores uso chatAt(), pero la función
         debe devolver un string, por eso asigno
         el valor de textReverse a un nuevo string "salida"
         */

        char[] textReverse = new char[texto.length()];

        for (int i = 0; i < texto.length(); i++) {
            textReverse[i] = texto.charAt(texto.length() - 1 - i);
        }

        String salida =  new String(textReverse);
        return salida;
    }
}
