import java.util.ArrayList;
import java.util.LinkedList;

public class CopiarEnLinkedList {
    /*
     * Problema:
     * 5. Crea un ArrayList de tipo String, con 4 elementos.
     * Cópialo en una LinkedList. Recorre ambos mostrando únicamente
     * el valor de cada elemento.
     */
    public static void main(String[] args) {

        // creo el ArrayList y lo relleno
        ArrayList<String> elementos = new ArrayList<String>();
        elementos.add("uno");
        elementos.add("dos");
        elementos.add("tres");
        elementos.add("cuatro");

        //creo la LinkedList y le copio los elementos del ArrayList
        LinkedList<String> copiaDeElementos = new LinkedList<String>();
        for (int i = 0; i < elementos.size(); i++) {
            copiaDeElementos.add(elementos.get(i));
        }

        // muestro la comparación
        for (int i = 0; i < elementos.size(); i++) {
            System.out.println(
                    "el valor en el ArrayList es: " + elementos.get(i)
            );
            System.out.println(
                    "el valor en la LinkedList es: " + copiaDeElementos.get(i) + "\n"
            );
        }
    }
}
