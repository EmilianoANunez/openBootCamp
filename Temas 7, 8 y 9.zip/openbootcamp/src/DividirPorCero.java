public class DividirPorCero {
    /*
     * Problema:
     * 7. Crea una función DividePorCero. Esta, debe generar una
     * excepción ("throws") a su llamante del tipo ArithmeticException
     * que será capturada por su llamante (desde "main", por ejemplo). Si
     * se dispara la excepción, mostraremos el mensaje "Esto no puede hacerse".
     * Finalmente, mostraremos en cualquier caso: "Demo de código".
     */
    public static void main(String[] args) {
        /*
         * creo los números a dividir y llamo a la función mediante
         * un try/catch que lanza un mensaje de error y finalmente un
         * mensaje de demostración
         */

        int num1 = 5;
        int num2 = 0;
        try {
            dividir(num1, num2);
        } catch (ArithmeticException e) {
            System.out.println("Esto no puede hacerse");
        } finally {
            System.out.println("Demo de código");
        }
    }
    public static int dividir (int num1, int num2) throws ArithmeticException{
        int resultado = num1 / num2;
        return resultado;
    }
}