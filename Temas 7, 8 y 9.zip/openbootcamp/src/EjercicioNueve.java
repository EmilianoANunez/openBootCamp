import java.io.*;
import java.util.HashMap;

public class EjercicioNueve {
    /*
     * este ejercicio es el siguiente:
     * 9. Sorpréndenos creando un programa de tu elección que utilice
     * InputStream, PrintStream, excepciones, un HashMap y un ArrayList,
     * LinkedList o array.
     */
    public static void main(String[] args) {
        // Creo un HashMap con nuevos usuarios.
        HashMap<String, Double> usurariosNuevos = new HashMap<>(); // HashMap
        usurariosNuevos.put("user6", 4102.45);
        usurariosNuevos.put("user7", 3190.12);
        usurariosNuevos.put("user8", 1310.66);

        // Leo un fichero de usuarios que tiene guardado los datos de un HashMap.
        // Actualizo el fichero con los nuevos usuarios.
        try {
            InputStream in = new FileInputStream("usuarios.txt"); // InputStream
            byte[] datos = in.readAllBytes(); // array

            PrintStream out = new PrintStream("usuarios_actualizado.txt"); // PrintStream
            out.write(datos);
            out.println("\n-nuevos usuarios: " + usurariosNuevos);
        } catch (Exception e) {
            System.out.println("Error capturado: " + e.getMessage()); // excepciones
        }
    }
}
