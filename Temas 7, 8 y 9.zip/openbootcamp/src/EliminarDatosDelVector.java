import java.util.Vector;

public class EliminarDatosDelVector {
    /*
     * Problema:
     * 3. Crea un "Vector" del tipo de dato que prefieras, y añádele
     * 5 elementos. Elimina el 2o y 3er elemento y muestra el
     * resultado final.
     */

    public static void main(String[] args) {

        Vector<String> saludos = new Vector();


        // añado 5 saludos
        saludos.add("holaa");
        saludos.add("buen día");
        saludos.add("buenas");
        saludos.add("holis");
        saludos.add("¿cómo estás?");

        System.out.println("antes: " + saludos);

        // remuevo el segundo y el tercer saludo
        saludos.remove(1);
        saludos.remove(2);

        System.out.println("después: " + saludos);
    }
}
