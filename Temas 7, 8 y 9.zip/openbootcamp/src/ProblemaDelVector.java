public class ProblemaDelVector {
    /*
     * Problema:
     * 4. Indica cuál es el problema de utilizar un Vector con la capacidad
     * por defecto si tuviésemos 1000 elementos para ser añadidos al mismo.
     */

    /*
     * El problema de utilizar un vector para crear tantos elementos
     * es que el vector crea un array subyacente de una capacidad mayor a la del tamaño.
     * pero cuando se llena el vector se duplica
     * Este proceso es costoso en procesamiento y capacidad de memoria.
     * Aunque esto se puede controlar con los parámetros: capacidad inicial e incremento.
     */
}
