package cocheYSuma;

public class cocheYSuma {
    public static void main(String[] args) {
        suma(4, 5, 76);
        Coche miCoche = new Coche();
        miCoche.sumarPuerta();
        System.out.println(miCoche.puertas);
    }

    public static int suma (int a, int b, int c) {
        int resultado =  a + b + c;
        System.out.println(resultado);
        return resultado ;
    }

    static class Coche {
        int puertas;
        void sumarPuerta() {
            puertas++;
        }
    }

}
