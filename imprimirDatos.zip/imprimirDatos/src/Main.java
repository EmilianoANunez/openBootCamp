public class Main {
    public static void main(String[] args) {
        String hola = "hola";
        Character a = 'a';
        int uno = 1;
        long largo = 1234567890123456323L;
        Boolean bool= true;

        System.out.println(
                "String: " + hola + "\n" +
                "Char: " + a + "\n" +
                "Int: " + uno + "\n" +
                "Long: " + largo + "\n" +
                "Boolean: " + bool
        );
    }
}