package com.poo;

import java.util.List;

public class CocheCRUDImpl implements CocheCRUD{

    @Override
    public void save() {

    }

    @Override
    public List<Coche> findAll() {
        return null;
    }

    @Override
    public void delete() {

    }

    String save = "guarda";
    String findAll = "busca";
    String delete = "borra";

    @Override
    public String toString() {
        return "CocheCRUDImpl{" +
                "save='" + save + '\'' +
                ", findAll='" + findAll + '\'' +
                ", delete='" + delete + '\'' +
                '}';
    }
}
