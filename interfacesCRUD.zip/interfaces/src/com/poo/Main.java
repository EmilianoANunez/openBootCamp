package com.poo;

public class Main {
    public static void main(String[] args) {

        CocheCRUD cocheCRUD = new CocheCRUDImpl();

        System.out.println(cocheCRUD);
    }
}