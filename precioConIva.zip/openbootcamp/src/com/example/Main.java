package com.example;

public class Main {
    public static void main(String[] args) {

        double precioProducto = calcularIva(349.99);
        System.out.println("El precio del producto más el IVA es de: " + precioProducto + "$");
    }
    static double calcularIva(double precio) {
        double iva = 0.23;
        return precio + (precio * iva);
    }
}


