package com.example;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingresa un precio: ");

        // por aquí se ingresa el precio del producto en consola
        // para introducir un double hay que utilizar ','
        double precioProducto = scanner.nextDouble();

        var precioConIva = calcularIva(precioProducto);

        System.out.println("El precio del producto más el IVA es de: " + precioConIva + "$");
    }
    static double calcularIva(double precio) {
        double iva = 0.23;
        return precio + (precio * iva);
    }
}


